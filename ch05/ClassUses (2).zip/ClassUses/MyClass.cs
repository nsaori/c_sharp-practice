﻿using System;

namespace ClassUses
{
    internal class MyClass
    {
        public string name;

        public void Method()
        {
            Console.WriteLine("My Clas Method()");
        }
    }
}